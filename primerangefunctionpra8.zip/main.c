/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int np(int,int);
int main()
{
    int n1,n2;
    printf("Please Enter the starting Point : ");
    scanf("%d",&n1);
    printf("Please Enter the Ending Point : ");
    scanf("%d",&n2);
    np(n1,n2);
    printf("\nProgram Executed by 20C23012 Vraj J Patel");
    return 0;
}
int np(int num1,int num2)
{
    int isprime,i,j;
    for(i = num1;i <= num2;i++)
    {
        isprime = 1;
        for(j = 2;j<=i/2;j++)
        {
            if(i%j == 0)
            {
                isprime = 0;
                break;
            }
        }
        if(isprime == 1)
            printf("%d ",i);
    }
}