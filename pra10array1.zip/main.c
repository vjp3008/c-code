/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
//Write a C Program to pass array element.
#include <stdio.h>
void main()
{
    int i;
    int marks[ ] = {10,20,30,40,50,60,70};
    printf("Array Elements are : ");
    for(i = 0;i<=6;i++)
        display(marks[i]); // function call
    printf("\nProgram Executed by 20C23012-Vraj J Patel");
}
display(int m)
{
    printf("\n%d ",m);
}
