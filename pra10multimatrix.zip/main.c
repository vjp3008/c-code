/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void main()
{
    int a[3][3],b[3][3],mul[3][3],r,c,i,j,k;
    printf("Enter the value of first matrix : \n");
    for(i = 0;i < 3;i++)
    {
        for(j = 0;j < 3;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    printf("Enter the value of seecond matrix : \n");
    for(i = 0;i < 3;i++)
    {
        for(j = 0;j < 3;j++)
        {
            scanf("%d",&b[i][j]);
        }
    }
    printf("Matrix 1 is : \n");
    for(i = 0;i < 3;i++)
    {
        for(j=0;j<3;j++)
        {
            printf("%d\t",a[i][j]);
        }
        printf("\n");
    }
    printf("Matrix 2 is : \n");
    for(i = 0;i < 3;i++)
    {
        for(j=0;j<3;j++)
        {
            printf("%d\t",a[i][j]);
        }
        printf("\n");
    }
    printf("Multiplication of matrix : \n");
    for(i = 0;i < 3;i++)
    {
        for(j = 0;j < 3;j++)
        {
            mul[i][j] = 0;
            for(k = 0;k<3;k++)
            {
                mul[i][j]+=a[i][k]*b[k][j];
            }
        }
    }
    
    for(i = 0;i < 3;i++)
    {
        for(j=0;j<3;j++)
        {
            printf("%d\t",mul[i][j]);
        }
        printf("\n");
    }
    printf("Program Executed by 20C23012-Vraj J Patel");
}
