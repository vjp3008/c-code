/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int marks[2][3];
    int i,j;
    for(i = 0; i < 2;i++)
    {
        for(j = 0;j < 3;j++)
        {
            printf("Enter Value for marks [%d][%d] : ",i,j);
            scanf("%d",&marks[i][j]);
        }
    }
    printf("\n---------------------------------------");
    printf("\n2 D Array Element are : \n");
    for(i = 0;i<2;i++)
    {
        for(j = 0;j<3;j++)
        {
            printf("%d ",marks[i][j]);
            if(j == 2)
            {
                printf("\n");
            }
        }
    }
    printf("\n---------------------------------------");
    printf("\nProgram Executed by 20C23012-Vraj J Patel");

    return 0;
}
