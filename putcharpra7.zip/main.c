/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int main()
{
    printf("\nProgram Executed by 20C23012-Vraj J Patel\n");
    int c,flag=1;
    while((c=getchar())!=EOF)
    {
        if(c==' '|| c=='\t')
        {
            flag=0;
        }
        else if(flag==0)
        {
            putchar('\n');
            putchar(c);
            flag=1;
        }
        else
        {
            putchar(c);
        }
        
    }
    return 0;
}