/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int fact(int);
void main()
{
    int number,factorial;
    printf("\nEnter number to find factorial : ");
    scanf("%d",&number);
    factorial = fact(number);
    printf("\nThe factorial of %d is %d",number,factorial);
    printf("\nProgram Executed by 20C23012-Vraj J Patel");
}
int fact(int n1)
{
    int fact = 1,i;
    for(i=1;i<=n1;i++)
    {
        fact = fact * i;
    }
    return fact;
}
