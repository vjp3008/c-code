/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void main()
{
    int a[2][2],b[2][2],c[2][2],i,j;
    printf("\nEnter value of matrix 1 : \n");
    for(i=0;i<2;i++)  //ROW
    {
        for(j=0;j<2;j++) //COLUMN
        {
            scanf("%d",&a[i][j]); //[0][0],[0][1],[1][0],[1][1],..........
        }
    }
    printf("\nEnter value of matrix 2 : \n");
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
        {
            scanf("%d",&b[i][j]);
        }
    }
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
        {
            c[i][j]=a[i][j]+b[i][j];
        }
    }
    printf("\nThe summation is : \n");
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
        {
            printf(" %d",c[i][j]);
        }
        printf("\n");
    }
    printf("Program Executed by 20C23012-Vraj J Patel");
}


