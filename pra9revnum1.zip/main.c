/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
void reversenum(int); // function prototype
void main()
{
    int num;
    printf("Enter the number : ");
    scanf("%d",&num);
    reversenum(num); // function call
    printf("Program Executed by 20C23012-Vraj J Patel");
}

void reversenum(int n) // function defination
{
    int originalnum,rem,reverse;
    originalnum = n;
    while (n>0)
    {
        rem = n % 10;
        reverse = reverse * 10 + rem;
        n = n / 10;
    }
    printf("Given Number = %d\n",originalnum);
    printf("Its reverse is : %d\n",reverse);
}