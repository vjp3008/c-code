/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int fibonacci(int i) // function defination
{
    if (i == 0)
    {
        return 0;
    }
    if (i == 1)
    {
        return 1;
    }
    return fibonacci(i - 1) + fibonacci(i - 2);
}
int main()
{
    int i;
    printf("\nFibonacci from 1 to 10 are\n ");
    for(i == 0;i<10;i++) //taking i as 10
    {
        printf("%d\t\n",fibonacci(i)); // function call
    }
    printf("Program Executed by 20C23012 - Vraj J Patel");
    return 0;
}
