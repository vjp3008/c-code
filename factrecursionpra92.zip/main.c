/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int factorial(int n) // function defination
{
    if(n == 1)
    {
        return 1;
    }
    return n * factorial(n-1);
}
int main()
{
    int num;
    int fact = 0;
    printf("Enter an integer number : ");
    scanf("%d",&num);
    fact = factorial(num); // function call
    printf("Factorial of %d is = %d",num,fact);
    printf("\n");
    printf("Program Executed by 20C23012-Vraj J Patel");
    return 0;
}
