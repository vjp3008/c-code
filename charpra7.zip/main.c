/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char input;
    printf("Enter the Character : ");
    input = getchar();
    printf("The Entered Character is : ");
    putchar(input);
    printf("\nProgram Executed by 20C23012 Vraj J Patel");

    return 0;
}
