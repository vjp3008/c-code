/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
//Write a C Program to print array element.
#include <stdio.h>
void main()
{
    int num[] = {10,20,30,40,50,60,70};
    float per[] = {10.3,100.45,45,67,89,65};
    char name[] = {'A','B','C','D'};
    int i;
    printf("Array Elements are : ");
    for(i = 0;i<=6;i++)
    {
        printf("\nElement number %d ",i);
        printf("%d is store at address = %u",num[i], &num[i]);
    }
    printf("\n----------------------------------------------------------");
    for(i = 0;i<=6;i++)
    {
        printf("\nElement number %d ",i);
        printf("%f is store at address = %u",per[i], &per[i]);
    }
    printf("\n----------------------------------------------------------");
    for(i = 0;i<=3;i++)
    {
        printf("\nElement number %d ",i);
        printf("%c is store at address = %u",name[i], &name[i]);
    }
    printf("\n----------------------------------------------------------");
    printf("\nProgram Executed by 20C23012-Vraj J Patel");
}