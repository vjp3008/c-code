/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <ctype.h>
main()
{
    char character;
    printf("Press any key\n");
    character = getchar();
    if (isalpha(character) > 0)
    printf("The data is a letter.");
    else
    if (isdigit (character))
    printf("The data is a digit.");
    else
    printf("The data is not alphanumeric.");
    printf("\nProgram Executed by 20C23012-Vraj J Patel");
}
