/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int sumd(int);
int main()
{
    int number,sum;
    printf("Enter a positive number : ");
    scanf("%d",&number);
    sum = sumd(number);
    printf("Sum of all digit is %d\n",sum);
    printf("\nProgram Executed by 20C23012-Vraj J Patel");
    return 0;
}
int sumd(int num)
{
    static int sum = 0;
    if(num>0)
    {
        sum+=(num%10);
        sumd(num/10);
    }
    else
    {
        return sum;
    }
}
