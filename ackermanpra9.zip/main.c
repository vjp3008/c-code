/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int A(int,int);
int main()
{
    int m,n;
    printf("Enter two numbers : ");
    scanf("%d%d",&m,&n);
    printf("Output : %d\n",A(m,n));
    printf("\nProgram Executed by 20C23012-Vraj J Patel");
    return 0;
}
int A(int m,int n)
{
    if(m == 0)
        return n+1;
    else if(n == 0)
        return A(m-1,1);
    else
        return A(m-1,A(m,n-1));
}
