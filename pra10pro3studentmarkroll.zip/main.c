/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void main()
{
    int stud[4][2];
    int i,j;
    for(i = 0;i <= 3;i++)
    {
        printf("\nEnter roll number and marks : ");
        scanf("%d %d",&stud[i][0],&stud[i][1]);
    }
    for (i = 0;i <= 3;i++)
    {
        printf("\nRoll number : %d Marks : %d",stud[i][0],stud[i][1]);
    }
    printf("\nProgram Executed by 20C23012-Vraj J Patel");

    return 0;
}

