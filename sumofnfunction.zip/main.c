/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int naturalno(int);
int main()  
{  
    int num, total;  
    printf("Enter a natural number: ");
    scanf("%d", &num);
    total = naturalno(num);
    printf(" Sum of the %d natural number is: %d", num, total);  
    printf("\nProgram Executed by 20C23012-Vraj J Patel");
}  
int naturalno(int num)
{  
    int i, sum = 0;  
    for (i = 0; i <= num; i++)  
    {  
        sum = sum + i;  
    }  
    return sum;  
}  

