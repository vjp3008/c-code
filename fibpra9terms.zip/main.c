/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void getfib(int,int,int);
int main()
{
    int a,b,sum,n,i;
    a = 0;
    b = 1;
    printf("Enter total number of terms : ");
    scanf("%d",&n);
    printf("Fibonacci series is : ");
    printf("%d\t%d\n",a,b);
    getfib(a,b,n-2);
    printf("\n");
    printf("Program Executed by 20C23012-Vraj J Patel");
    return 0;
}

void getfib(int a,int b, int n)
{
    int sum;
    if(n>0)
    {
        sum = a + b;
        printf("%d",sum);
        a=b;
        b=sum;
        getfib(a,b,n-1);
    }
}