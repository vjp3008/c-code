/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Write a C Program to Make aa Multiplication Table
#include <stdio.h>
#define ROWS 5
#define COLUMNS 5
void main()
{
    int row,column;
    int product[ROWS][COLUMNS];
    int i,j;
    printf("Multiplication Table : \n");
    printf("    ");
    for (j=1 ;j<=COLUMNS;j++)
    {
        printf("%4d",j);
    }
    printf("\n------------------------------\n");
    for(i=0;i<ROWS;i++)
    {
        row = i+1;
        printf("%2d |",row);
        for(j=1;j<=COLUMNS;j++)
        {
            column = j;
            product[i][j] = row * column;
            printf("%4d",product[i][j]);
        }
        printf("\n");
    }
    printf("Program Executed by 20C23012 Vraj J Patel");
}

