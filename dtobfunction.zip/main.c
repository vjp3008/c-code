/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
void dtob(int);
int main()
{
    int number;
    printf("\n Please enter a number you want to convert : ");
    scanf("%d",&number);
    dtob(number);
    return 0;
}
void dtob(int n)
{
    int a[10],i,j;
    for(i = 0; n > 0; i++)
    {
        a[i] = n % 2;
        n = n / 2;
    }
    printf("\n Binary number of a given number = ");
    for(j = i - 1; j >= 0; j--)
    {
        printf(" %d",a[j]);
    }
    printf("\n");
    printf(" Program Executed by 20C23012 - Vraj J Patel");
}
