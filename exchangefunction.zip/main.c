/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
void exchange (int,int);
void main()
{
int x,y;
printf("Enter the values of x,y");
scanf("%d %d",&x,&y);
exchange(x,y);
}

void exchange (int a,int b)

{
int temp;
printf("The values of a and b before exchange are as follows");
printf("\na=%d", a);
printf("\nb-%d",b);
temp=a;
a=b;
b=temp;
printf("\nThe values of a and b after exchange are as follows");
printf("\na-%d", a);
printf("\nb-%d",b);
}

