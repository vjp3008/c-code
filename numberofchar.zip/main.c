/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
void main()
{
    char c;
    int noc=0;
    while((c=getchar())!= 'V')
    {
        noc++;
    }
    printf("\nNo of characters=%d",noc);
    printf("\nProgram Executed by 20C23012-Vraj J Patel");
}

