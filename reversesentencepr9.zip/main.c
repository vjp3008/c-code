/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void reverse();
int main()
{
    printf("Enter a sentence : ");
    reverse();
    printf("\nProgram Executed by 20C23012-Vraj J Patel");
    return 0;
}
void reverse()
{
    char ch;
    scanf("%c",&ch);
    if(ch != '\n')
    {
        reverse();
        printf("%c",ch);
    }
}