/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int sum(int,int,int),sub(int,int,int),mul(int,int,int),divi(int,int,int);
int main()
{
    int n1,n2,n3,result1,result2,result3,result4;
    printf("Enter Three Numbers :");
    scanf("%d%d%d",&n1,&n2,&n3);
    
    result1=sum(n1,n2,n3);
    result2=sub(n1,n2,n3);
    result3=mul(n1,n2,n3);
    result4=divi(n1,n2,n3);
    
    printf("\nThe Summation of %d %d and %d is %d",n1,n2,n3,result1);
    printf("\nThe Subtraction of %d %d and %d is %d",n1,n2,n3,result2);
    printf("\nThe Multiplication of %d %d and %d is %d",n1,n2,n3,result3);
    printf("\nThe Division of %d %d and %d is %d",n1,n2,n3,result4);
    printf("\nProgram Executed by 20C23012-Vraj J Patel\n ");
}
int sum(int n1,int n2,int n3)
{
    int sum;
    sum=n1+n2+n3;
    return sum;
}
int sub(int n1,int n2,int n3)
{
    int sub;
    sub=n1-n2-n3;
    return sub;
}
int mul(int n1,int n2,int n3)
{
    int mul;
    mul=n1*n2*n3;
    return mul;
}
int divi(int n1,int n2,int n3)
{
    int divi;
    divi=(n1/n2)/n3;
    return divi;
}
