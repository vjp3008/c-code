/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int prime(int);
void main()
{
    int n, result;
    printf("\nEnter number: ");
    scanf("%d", &n);
    result=prime(n);
    printf("%d ", result );
    printf("\nProgram Executed by 20C23012-Vraj J Patel");
}
int prime (int num)
{
    int i, flag=0;
    for (i=2; i<num; i++)
    {
        if ((num%i )==0)
        flag++;
    }
    if(flag>0)
        return 0;
    else
        return 1;

}
