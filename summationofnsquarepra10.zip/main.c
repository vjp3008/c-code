/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

void main()
{
    int i;
    float x[10],value,total;
    printf("Enter 10 Real Numbers : ");
    for(i = 0; i < 10;i++)
    {
        scanf("%f",&value);
        x[i] = value;
    }
    total = 0.0;
    for(i = 0; i<10;i++)
    {
        total = total + x[i] * x[i];
    }
    printf("\n");
    for(i = 0;i < 10;i++)
    {
        printf("x[%2d] = %5.2f\n",i + 1,x[i]);
    }
    printf("\ntotal =  %.2f\n",total);
    printf("ProgramExecuted by 20C23012-Vraj J Patel");
}
